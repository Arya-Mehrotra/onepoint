<?php
session_start();
ini_set('display_errors',0);
if($_POST['action']){
    echo count($_SESSION['cart']['id']);
}

?>