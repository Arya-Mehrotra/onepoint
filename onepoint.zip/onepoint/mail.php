<?php
$to = "hsri1989@gmail.com,floorteam.op@gmail.com";
$subject = "HTML email";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p>This email contains HTML Tags!</p>
<table>
<tr>
<td>Firstname</td>
<td>'.$_POST[fn].'</td>
</tr>
<tr>
<td>Last Name</td>
<td>'.$_POST[ln].'</td>
</tr>
<tr>
<td>Phone</td>
<td>'.$_POST[pno].'</td>
</tr>
<tr>
<td>Address</td>
<td>'.$_POST[ad].'</td>
</tr>
<tr>
<td>Potal Code</td>
<td>'.$_POST[pco].'</td>
</tr>
</table>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
//$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: myboss@example.com' . "\r\n";

if(mail($to,$subject,$message,$headers)){
    session_start();
    $_SESSION['msg']='Mail send sucessfully';
    header('location:cart.html');
}
?>