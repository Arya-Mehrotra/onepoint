<?php
session_start();
//$_SESSION['cart']=['id'=>[],'location_service'=>[]];
if(!isset($_SESSION['cart'])){
$_SESSION['cart']=['id'=>[],'location_service'=>[],'qty'=>[]];
array_push($_SESSION['cart']['id'],$_POST['id']);
  array_push($_SESSION['cart']['qty'],$_POST['qty']);
  echo count($_SESSION['cart']['id']); 
}else{
    if(!in_array($_POST['id'],$_SESSION['cart']['id'])){
        array_push($_SESSION['cart']['id'],$_POST['id']);
        array_push($_SESSION['cart']['qty'],$_POST['qty']);
    echo count($_SESSION['cart']['id']); 
    }else{
     echo 'err';    
    }
}
?>