<?php
require 'Db.php';
class Query extends Db{
    public function select($table){
       $sql="select * from $table";
       $execute=mysqli_query($this->conn,$sql);
       $result=[];
       while($record=mysqli_fetch_assoc($execute)){
               array_push($result,$record);
       }
       return $result;
    }
 public function get_services($id){
    $sql="select services.Id,services.Name,services.desc_box_h1,services.desc_box_h2,services.desc_box_h3,services.desc_box_h1_desc,services.desc_box_h2_desc,services.desc_box_h3_desc,services.DisplayPriority,services.ServiceUrl,location_services.url,location_services.title from services inner Join location_services on services.ID=location_services.service where location_services.CityId=$id and location_services.featured='1' and location_services.status='1' order by services.DisplayPriority ASC;";
    $sql2="Select * from location_services WHERE status='1' AND CityId=$id ORDER BY service_position ASC";
    $exe=mysqli_query($this->conn,$sql);
    $exe2=mysqli_query($this->conn,$sql2);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
         array_push($result,$record);
    }
     //create sub service file
         while($record2=mysqli_fetch_assoc($exe2)){
         $subservice_file=$record2['url'].'.html';
    if(!file_exists('city-service/'.$subservice_file)){
            fopen('city-service/'.$subservice_file,'w');
            copy('service.html','city-service/'.$subservice_file);
     }
         }
     return $result;
 }
 public function get_where($table,$array){
     $where='';
     foreach($array as $key=>$val){
          $where.=$key.'="'.$val.'" and ';
     }
     $where=rtrim($where,' and');
     $sql="select * from $table where $where";
      $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
          array_push($result,$record);
     }
     return $result;
 }
  public function get_reviews($table,$id,$order,$limit){
     $sql="select * from $table where location_service=$id order by id $order limit $limit";
      $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
          array_push($result,$record);
     }
     return $result;
 }
public function get_all_service($id){
 $sql="select services.Id,services.Name,services.DisplayPriority,services.ServiceUrl,location_services.url,location_services.title from services inner Join location_services on services.id=location_services.service where location_services.CityId=$id order by services.DisplayPriority ASC";    
  $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
         array_push($result,$record);
     }
     return $result;
}
public function fetch_tasks($table,$id){
  $sql="select * from $table where location_service_id=$id";
  $exe=mysqli_query($this->conn,$sql);
    $result=[];
     while($record=mysqli_fetch_assoc($exe)){
          array_push($result,$record);
     }
     return $result;
}
}
?>