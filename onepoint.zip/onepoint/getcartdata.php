<?php
session_start();
require 'autoload.php';
$db=new Query();
$html=new CreateHtml();
$tasks=[];
if(isset($_POST['action'])){
foreach($_SESSION['cart']['id'] as $id){
    array_push($tasks,$db->get_where('sub_services_tasks',['id'=>$id])[0]);
}
$html->create_json('cart.json',$tasks);
// $html->create_json('qty.js',$_SESSION['cart']['qty']);

    $file=fopen('qty.js','w');
    $data='var qty='.json_encode($_SESSION['cart']['qty']);
    fwrite($file,$data);

}
?>