<?php
error_reporting(E_ALL);
ini_set('display_error','1');
require 'autoload.php';
$db=new Query();
$html=new CreateHtml();
if(isset($_POST['url'])){
$records=$db->get_where('location_services',['url'=>$_POST['url']]);
echo $records[0]['id'];
}
if(isset($_POST['service_id'])){
    $subservice=$db->get_where('locationsubservice',['location_service_id'=>$_POST['service_id']]);
    //$brands=$db->get_where('service_brand',['service_id'=>$_POST['service_id']]);
    $tasks=$db->get_where('location_sub_service_tasks',['location_service_id'=>$_POST['service_id']]);
    $html->create_json('subservice.json',$subservice);
   // $html->create_json('brands.json',$brands);
    $html->create_json('tasks.json',$tasks);
}

if(isset($_POST['taskid'])){
    $tasks=$db->get_where('sub_services_tasks',['id'=>$_POST['taskid']]);
    $json=json_encode($tasks[0]);
    echo $json;
    // $file=fopen('tasklist.json','a');
    // fwrite($file,$json);
    // fclose($file);
}
?>