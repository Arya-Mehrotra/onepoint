<?php
error_reporting(E_ALL);
ini_set('display_error','1');
require 'autoload.php';
$db=new Query();
$html=new CreateHtml();
if(isset($_POST['id'])){
  $servicedata=$db->get_services($_POST['id']);
  $html->create_json('services.json',$servicedata);
}
?>