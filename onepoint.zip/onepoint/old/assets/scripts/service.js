//service
let url=window.location.href;
let filename=url.split('/').pop();
let file_without_ext=filename.split('.')[0];
$.get('city.json',function(data){
       $.each(data,function(index){
        if(data[index].url==file_without_ext){
          $.post('servicejson.php',{id:data[index].CityId},function(response){
            $.get('services.json',function(servicedata){
              let service_block='';
                $.each(servicedata,function(serviceindex){
                  service_block +='<div class="col serviceItem">'+
    '<a href="city-service/'+servicedata[serviceindex].url+'.html" class="card rounded-3 text-center text-reset text-decoration-none text-capitalize justify-content-center">'+
    '<div class="card-body"><img src="./assets/images/split-ac-icon.svg" alt="service-1" class="serviceIcon">'+
    '<div class="serviceTitle">'+servicedata[serviceindex].Name+'</div></div></a></div>';
                });
                $('.serviceSelection').html(service_block);
            });       
          });
        }
       });
});
$('.display-1').html(file_without_ext.toUpperCase());
$('.mx-2').html(file_without_ext);