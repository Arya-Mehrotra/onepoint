<?php
session_start();
require 'includes/config.php';
$conn=mysqli_connect(server,user,password,database) or die('Database Connection Failed');
$name=trim($_POST['fn']);
$last=trim($_POST['ln']);
$email=trim($_POST['email']);
$phone=trim($_POST['pno']);
$alternate=trim($_POST['alternate_num']);
$address=trim($_POST['address']);
$landmark=trim($_POST['landmark']);
$pcode=trim($_POST['pcode']);
$city=trim($_POST['city']);
$state=trim($_POST['state']);
$msg=trim($_POST['message']);
$payment_mode=trim($_POST['paymentMode']);
$service=implode(',',$_SESSION['cart']['id']);
$fullname=$name.' '.$last;
$sql="Insert into orders(state,city,service,name,mobile,alternate_num,address,pcode,landmark,message,paymentMode) VALUES ('$state','$city','$service','$fullname','$phone','$alternate','$address','$pcode','$landmark','$msg','$payment_mode')";
$exe=mysqli_query($conn,$sql);
if($exe){
    echo '<script>alert("Order Recieved Sucessfully");</script>';
    unset($_SESSION['cart']);
    header('location:index.html');
}
?>