<?php
session_start();
$key=array_search($_POST['id'],$_SESSION['cart']['id']);
unset($_SESSION['cart']['id'][$key]);
unset($_SESSION['cart']['qty'][$key]);
?>