//service
let url=window.location.href;
let filename=url.split('/').pop();
let file_without_ext=filename.split('.')[0];
$.get('city.json',function(data){
       $.each(data,function(index){
        if(data[index].url==file_without_ext){
             $('title').text(data[index].metaTitle);
          $('meta[name="description"]').attr('content',data[index].metaDescription);
          $.post('servicejson.php',{id:data[index].CityId},function(response){
            $.get('services.json',function(servicedata){
              let service_block='';
                $.each(servicedata,function(serviceindex){
                  service_block +='<div class="col serviceItem">'+
    '<a href="city-service/'+servicedata[serviceindex].url+'.html" class="card rounded-3 text-center text-reset text-decoration-none text-capitalize justify-content-center">'+
    '<div class="card-body"><img src="./assets/images/split-ac-icon.svg" alt="service-1" class="serviceIcon">'+
    '<div class="serviceTitle">'+servicedata[serviceindex].Name+'</div></div></a></div>';
                });
              $('.serviceSelection').html(service_block);
            });  
            //read all services for respective cities
            $.get('allservice.json',function(allservicedata){
                 $('.all-service-list').empty();
                 $('.all-service-list').css({'height':'500px','overflow-y':'scroll'});
                // all-service-list
                $.each(allservicedata,function(allserviceindex){
                    let field='<div class="col-12 serviceItem">'+
              '<a href="city-service/'+allservicedata[allserviceindex].url+'.html" class="card subServiceCard rounded-3 text-decoration-none">'+
             '<div class="card-body p-1 pe-2 p-md-2"><div class="row"><div class="col-auto pe-0">'+
           '<img class="img-fluid subServiceImg" src="./assets/images/service-gas-filling.webp" alt="gas-filling"></div>'+
            '<div class="col"><div class="row flex-nowarp h-100 align-items-center">'+
        '<div class="col pe-0"> <div class="card-title text-primary fw-bold mb-0">'+allservicedata[allserviceindex].Name+'</div>'+
    '<p class="card-text text-muted mt-1 mb-0">'+allservicedata[allserviceindex].title+'</p></div>'+
     '<div class="col-auto text-end text-muted fs-3"><i class="fa-solid fa-angle-right"></i>'+
    '</div></div></div></div></div></a></div>'
                    $('.all-service-list').append(field);
                });
            });
          });
        }
       });
});

  $.get('../reviews.json',function(reviewsdata){
          if(reviewsdata.length > 0){
          $('.custTestimonialSwiper').find('.swiper-slide-active').empty();
         $('.custTestimonialSwiper').find('.swiper-slide-next').empty();
           let loop=1;
          $.each(reviewsdata,function(reviewsdataindex){
      let testimonial_card='<div class="avatarMetaWrap"><img src="./assets/images/customer.webp" class="customAvatar rounded-circle" alt="customer">'+
                  '<div class="customerMeta d-block d-lg-none"><h4 class="customerMeta--name">'+reviewsdata[reviewsdataindex].client_name+'<p class="small customerMeta--city"></p>'+
                  '</h4></div></div>'+
                '<p class="customerReview mb-0">'+reviewsdata[reviewsdataindex].review+'</p>'+
                '<div class="customerMeta d-none d-lg-block"><h4 class="customerMeta--name">'+reviewsdata[reviewsdataindex].client_name+'</h4><p class="customerMeta--city">Sitapur</p></div>';
    if(loop > 4){
      $('.custTestimonialSwiper').find('.swiper-slide-next').append(testimonial_card); 
    }else{
        $('.custTestimonialSwiper').find('.swiper-slide-active').append(testimonial_card);
    }
              loop++;
          });
      }
      });
$('.display-1').html(file_without_ext.toUpperCase());
$('.mx-2').html(file_without_ext);