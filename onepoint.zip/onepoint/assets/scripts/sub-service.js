let href=window.location.href;
let filename=href.split('/').pop();
let filename_without_ext=filename.split('.')[0];
let city=filename_without_ext.split('-').pop();
let service_name=filename_without_ext.replaceAll('-',' ');
$('.mx-2').html('You are in '+ city);
$('.title-city-service').text('Best Rated '+service_name);
$.post('../get_subservice.php',{url:filename_without_ext},function(recdata){
 let jsonrec=JSON.parse(recdata);
 $('title').text(jsonrec[0].MetaTitle);
 $('head').append('<meta name="description" content="'+jsonrec[0].MetaDescription+'">');
  $('head').append('<meta name="keywords" content="'+jsonrec[0].metakeyword+'">');
  
  //faq
  $.post('../fetchfaq.php',{sid:jsonrec[0].id},function(faqresponse){
      $.get('../faq.json',function(faqjsonparse){
          if(faqjsonparse.length > 0){
              let count=Math.round(faqjsonparse.length/2);
              $('#faqAccordion').empty();
         let faq_accord='<div class="col-md-6">';     
          $.each(faqjsonparse,function(faqindex){
         faq_accord+='<div class="accordion-item"><h2 class="accordion-header" id="heading'+faqjsonparse[faqindex].ID+'">'+
'<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne'+faqjsonparse[faqindex].ID+'" aria-expanded="false" aria-controls="collapseOne">'+
           faqjsonparse[faqindex].q+'</button></h2>'+
            '<div id="collapseOne'+faqjsonparse[faqindex].ID+'" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion" style="">'+
            '<div class="accordion-body">'+faqjsonparse[faqindex].a+'</div></div></div>';
            if(faqindex==count-1){
                faq_accord+='</div><div class="col-md-6">';
            }
              $('#faqAccordion').html(faq_accord);
          });
      }
      });
  });
  
  //content
  $.post('../singleservice.php',{sid:jsonrec[0].service},function(faqresponse){
      $.get('../singleservice.json',function(servicejson){
          if(servicejson.length > 0){
              //first block
              $('.storeMeta').find('.ms-3').text(servicejson[0].desc_box_h1);
              $('.storeMeta').find('.ms-3').parent().next().html(servicejson[0].desc_box_h1_desc);
              //second block
              $('.mb-3').text(servicejson[0].desc_box_h2);
              $('.storeMeta').find('.mb-3').next().html(servicejson[0].desc_box_h2_desc);
              //third block
             $('.storeMeta').find('.mb-2').text(servicejson[0].desc_box_h3);
      }
      });
  });
  
   //reviews
  $.post('../fetchreviews.php',{sid:jsonrec[0].id},function(reviewsresponse){
      $.get('../reviews.json',function(reviewsdata){
          if(reviewsdata.length > 0){
          $('.custTestimonialSwiper').find('.swiper-slide-active > .row').empty();
         $('.custTestimonialSwiper').find('.swiper-slide-next > .row').empty();
           let loop=1;
          $.each(reviewsdata,function(reviewsdataindex){
      let testimonial_card='<div class="col-12 col-lg-6"><div class="card custTestimonialCard rounded-0"><div class="card-body"><div class="row flex-nowarp">'+
    '<div class="col-auto pe-0 custImg"><img src="../assets/images/customer1.webp" alt="gas-filling"></div>'+
    '<div class="col custText"><figure><div class="starRating" style="--rating: '+reviewsdata[reviewsdataindex].rating+'; font-size:15px;"></div>'+
    '<blockquote class="blockquote mb-1"><p class="card-text">'+reviewsdata[reviewsdataindex].review+'“</p>'+
    '</blockquote><figcaption class="blockquote-footer text-muted">'+reviewsdata[reviewsdataindex].client_name+
    '<span class="d-block d-xxl-inline ms-xxl-3"><i class="fa fa-location-dot me-1"></i>'+reviewsdata[reviewsdataindex].area+'</span></figcaption>'+
    '</figure></div></div></div></div></div>';
    if(loop > 4){
      $('.custTestimonialSwiper').find('.swiper-slide-next > .row').append(testimonial_card); 
    }else{
        $('.custTestimonialSwiper').find('.swiper-slide-active > .row').append(testimonial_card);
    }
              loop++;
          });
      }
      });
  });
  
     //bookinngs
  $.post('../bookings.php',{sid:jsonrec[0].service},function(bookingresponse){
      $.get('../bookings.json',function(bookingdata){
          if(bookingdata.length > 0){
              $('.bookingSwiper > .swiper-wrapper').empty();
              let loop=1;
          $.each(bookingdata,function(bookingdataindex){
              let status;
              if(loop==1){
                  status='swiper-slide-active';
              }else if(loop==2){
                   status='swiper-slide-next';
              }else{
                  status="";
              }
        let booking_card='<div class="swiper-slide pt-3 '+status+'" role="group" aria-label="1 / 8" style="width: 306px; margin-right: 24px;">'+
        '<div class="card"><div class="card-body">'+
        '<h6 class="bookedService card-title mb-1 fw-bold">AC Service Repair</h6>'+
       '<div class="card-text mb-2 small">My AC is not working, its not cooling and neither operating well.</div></div>'+
    '<div class="card-footer bg-transparent"><div class="row gx-3 flex-nowrap"><div class="col-auto">'+
   '<span class="badge bg-dark bg-opacity-10 rounded-circle text-dark border"><i class="fa fa-user"></i></span></div>'+
    '<div class="col fs-6 mt-1"><h6 class="fw-bold mb-0 small">Manisha Kumari</h6><p class="small mb-0">'+
    '<span class="d-block d-xxl-inline"><i class="fa fa-location-dot me-1"></i> Ramnagar, Lakhimpur (UP)</span></p>'+
    '</div></div></div></div></div>';
           $('.bookingSwiper').find('.swiper-wrapper').append(booking_card);
           loop++;
          });
      }
      });
  });
  
$.post('../get_subservice.php',{service_id:jsonrec[0].id,brand:jsonrec[0].service},function(response){
    $.get('../subservice.json',function(subservice){
        $('.serviceSelection').empty();
         $.each(subservice,function(index){
    let block='<div class="col serviceItem">'+
    '<a href="#" class="card rounded-3 text-center text-reset text-decoration-none text-capitalize justify-content-center">'+
     '<div class="card-body"><img src="../assets/images/'+subservice[index].image+'" alt="service-1" class="serviceIcon">'+
      '<div class="serviceTitle">'+subservice[index].title+'</div></div></a></div>';
            $('.serviceSelection').append(block);
         });
    });
    //brands
    $.get('../brands.json',function(brands){
        $('.brandsSwiper').empty();
         $.each(brands,function(index){
    let single_brand='<div class="swiper-slide swiper-slide-duplicate" style="width: auto; margin-right: 30px;" data-swiper-slide-index="0" role="group" aria-label="1 / 8">'+
    '<img src="../assets/images/'+brands[index].image+'" alt="blue-star" class="img-fluid"></div>';
        //   $('.brandsSwiper').append(single_brand);
         });
    });
    
    //professionals
    $.get('../pro.json',function(prodata){
        $('.servProfessRow').empty();
        $.each(prodata,function(proindex){
        let procard='<div class="col-12 col-md-6 col-xl-4"><div class="card servProfessCard rounded-0">'+
                '<div class="card-body"><div class="row flex-nowarp">'+
                '<div class="col-auto pe-0 servProfessImg"><img src="../assets/images/customer1.webp" alt="gas-filling"></div>'+
                '<div class="col servProfessText d-flex flex-column"><figure class="m-0 h-100">'+
                '<h4 class="card-title fw-bold text-muted mb-1">'+prodata[proindex].name+'</h4>'+
                '<div class="servProfessLocation text-muted mb-2"><i class="fa fa-location-dot me-1"></i>'+prodata[proindex].location+'</div>'+
                '<div class="jobsRating mt-auto"><div class="starRating" style="--rating: '+prodata[proindex].rating+'; font-size:15px;"></div><span class="jobsCount">400+ Jobs</span>'+
                '</div></figure></div></div></div></div></div>';
                $('.servProfessRow').append(procard);
        });
    });
   });
});

//Professionals  servProfessRow
$(document).ready(function(){
    $.get('../tasks.json',function(data){
     if(data.length!==0){
     $('.task-container').empty();
     $.each(data,function(index){
     $.post('../get_subservice.php',{taskid:data[index].service_task_id},function(response){
        let json=JSON.parse(response); 
               let card='<div class="col-12"><div class="card subServiceCard rounded-3">'+
               '<div class="card-body p-2 p-md-3"><div class="row">'+
             '<div class="col-3 col-md-auto pe-0">'+
              '<img class="img-fluid subServiceImg" src="../assets/images/service-gas-filling.webp" alt="gas-filling"></div>'+
             '<div class="col"><div class="row flex-nowarp h-100 align-items-center">'+
             '<div class="col pe-0"><div class="card-title text-primary fw-bold mb-0">'+json.task_name+
        '<span class="ms-1 badge bg-warning rounded-circle p-1" data-bs-placement="top" data-bs-toggle="tooltip" data-bs-title="Service Explanation">'+
        '<i class="fa-solid fa-exclamation"></i></span></div>'+
        '<p class="card-text text-muted mt-1 mb-0">Best Service Availabe in the town</p></div>'+
        '<div class="col-auto text-end"><div class="subServicePrice fw-bold lh-1"><span>₹</span>'+json.task_price+
        '<p class="small text-muted fs-normal mt-1">(Tax Included)</p></div></div></div></div></div></div>'+
        '<div class="card-footer p-2 p-md-3 border-top-0 text-end">'+
        '<div class="qtyGroup d-inline-flex fl-l" role="group"><button type="button" id="d'+json.id+'" onclick="decrement(this.id)" class="btn btn-sm btn-link px-2 decrem"><i class="fa-solid fa-minus"></i></button>'+
      '<input type="text" name="incrementer_val" class="form-control form-control-sm text-center" value="1"><button type="button" id="'+json.id+'" onclick="increment(this.id)" name="increm" class="btn btn-sm btn-link px-2 increm"><i class="fa-solid fa-plus"></i></button></div>'+
        '<a href="javascript:;" onclick="cart('+json.id+',this.id)" id="b'+json.id+'" name="addtocart" data-qty="1" data-price="'+json.task_price+'" class="btn-add btn btn-primary btn-sm text-white ms-auto fw-bold">Add Now'+
        '</a></div></div></div>';
       $('.task-container').append(card);
     });
     });
}
});
});

function cart(id,btn){
 //task
 let qty=$('#'+btn).data('qty');
    $.post('../cart.php',{id:id,qty:qty},function(response){
        if(response!='err'){
        $('.cart-badge').show();
        $('.cart-badge').html(response);  
        }else{
            alert('This task has already been added');
        }
    });
}
 function increment(id){
     $('#'+id).prev().val(parseInt($('#'+id).prev().val())+1);
       $('#'+id).parent().next().attr('data-qty',parseInt($('#'+id).prev().val()));
 }
 
 function decrement(id){
    if($('#'+id).next().val() > 1){
     $('#'+id).next().val(parseInt($('#'+id).next().val())-1); 
      $('#'+id).parent().next().attr('data-qty',parseInt($('#'+id).next().val()));
    }
 }
